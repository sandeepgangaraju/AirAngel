import tweepy
import json
import pyodbc
from dateutil import parser

WORDS = []

CONSUMER_KEY = ""
CONSUMER_SECRET = ""
ACCESS_TOKEN = ""
ACCESS_TOKEN_SECRET = ""



# into a MySQL database
def store_data(name, description, profile_image_url, followers_count):
    cnxn = pyodbc.connect(r'Driver={SQL Server};Server=.\SQLEXPRESS;Database=myDB;Trusted_Connection=yes;')
    cursor = cnxn.cursor()
    insert_query = "INSERT INTO userinfo (name, description, profile_image_url, followers_count) VALUES (%s, %s, %s, %s)"
    cursor.execute(insert_query, (tweet_id, screen_name, created_at, text, coordinates))
    db.commit()
    cursor.close()
    db.close()
    return

class StreamListener(tweepy.StreamListener):
    #This is a class provided by tweepy to access the Twitter Streaming API.

    def on_connect(self):
        # Called initially to connect to the Streaming API
        print("You are now connected to the streaming API.")

    def on_error(self, status_code):
        # On error - if an error occurs, display the error / status code
        print('An Error has occured: ' + repr(status_code))
        return False

    def on_data(self, data):
     
        try:
           # Decode the JSON from Twitter
            datajson = json.loads(data)

            if datajson['coordinates'] is None:
                print('coordinates = None, skipped')

            else:

            #grab the wanted data from the Tweet
                name = datajson['name']
                description = datajson['description']
                followers_count = datajson['followers_count']
                profile_image_url = parser.parse(datajson['profile_image_url'])
             
                #print datajson
                #insert the data into the MySQL database
                store_data(name, description, followers_count, profile_image_url)

        except Exception as e:
           print(e)
auth = tweepy.OAuthHandler(CONSUMER_KEY, CONSUMER_SECRET)
auth.set_access_token(ACCESS_TOKEN, ACCESS_TOKEN_SECRET)

#Set up the listener. The 'wait_on_rate_limit=True' is needed to help with Twitter API rate limiting.

listener = StreamListener(api=tweepy.API(wait_on_rate_limit=True))
streamer = tweepy.Stream(auth=auth, listener=listener)
print("Tracking: " + str(WORDS))
streamer.filter(track=WORDS)
