

select count(distinct taster_name) from reviews;

select taster_name, count(*) from reviews where taster_name is not null
group by taster_name having count(*) >= 5 order by taster_name ;


