
/*creating the database */
create database airangel;

/*pointing to airangel */
USE [airangel];

/*creating vino user */

create login vino with password = 'vino';

create user [vino] for login [vino];

