USE airangel
GO

DECLARE @json_data VARCHAR(MAX)


SELECT @json_data = 
		BulkColumn
		FROM OPENROWSET(BULK'C:\Users\Sandy\Desktop\Airangel\dataengineerapi-main\winemag-data-130k-v2-formatted.json',SINGLE_BLOB) JSON

--SELECT @json_data as json_data1

INSERT INTO reviews (points,title,description,taster_name,taster_twitter_handle,price,designation,variety,region_1,region_2,province,country,winery)
	SELECT points,title,description,taster_name,taster_twitter_handle,price,designation,variety,region_1,region_2,province,country,winery
	FROM OPENJSON(@json_data)
	WITH (
			points					varchar(100),
			title					varchar(100),
			description				varchar(1000),
			taster_name				varchar(100),
			taster_twitter_handle	varchar(100),
			price					varchar(100),
			designation				varchar(100),
			variety					varchar(100),
			region_1				varchar(100),
			region_2				varchar(100),
			province				varchar(100),
			country					varchar(100),
			winery					varchar(100)	
		);
GO

	
	SELECT COUNT(1) FROM REVIEWS;
