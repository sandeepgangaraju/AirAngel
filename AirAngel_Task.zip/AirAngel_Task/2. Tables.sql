USE airangel
GO

IF OBJECT_ID('reviews','U') IS NOT NULL
	DROP TABLE reviews;
GO

CREATE TABLE reviews (
	points					varchar(100),
	title					varchar(100),
	description				varchar(1000),
	taster_name				varchar(100),
	taster_twitter_handle	varchar(100),
	price					varchar(100),
	designation				varchar(100),
	variety					varchar(100),
	region_1				varchar(100),
	region_2				varchar(100),
	province				varchar(100),
	country					varchar(100),
	winery					varchar(100)	
	);

IF OBJECT_ID('userinfo','U') IS NOT NULL
	DROP TABLE userinfo;
GO

CREATE TABLE userinfo (
	id					int IDENTITY(1,1) PRIMARY KEY,
	name				varchar(100),
	description			varchar(1000),
	profile_image_url	varchar(1000),
	followers_count		varchar(100)

	);

GO


sp_help reviews;
GO

sp_help userinfo;
GO